## -----------------------------------------------------------------------------
  rm(list=ls())

## --- 2.6 Correlation functions -----------------------------------------------
  source('GPCore.R')
  load('Model2.RData')
  plot(x_M2, y_M2,'l')


## --- Generate the data -------------------------------------------------------
  ind = c(1,30,60,90,120,150,180)
  X = matrix(x_M2[ind,1],ncol=1)
  Y = matrix(y_M2[ind],ncol=1)

## --- Build the emulator ------------------------------------------------------
  E = GPCore()
  E$InputData(X)
  E$OutputData(Y)
  E$SetCorFun('GausCor')

## --- Likelihood --------------------------------------------------------------
  N = 1000
  delta_max = 2 
  delta = seq(from=0.0001, to=delta_max, length.out=N)
  LogLik = rep(0,N);
  
  for (k in 1:N) {
    LogLik[k] = E$LogLik(delta[k])$L
  }
  plot(delta,LogLik)
  deltahat = delta[which.max(LogLik)]
  deltahat


## --- Plot --------------------------------------------------------------------
  E$SetHyper(deltahat)
  E$Plot(x_M2)
  lines(x_M2,y_M2)
