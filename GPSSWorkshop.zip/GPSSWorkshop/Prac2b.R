## ----------------------------------------------------------------------------- 
  rm(list=ls())

## --- Load files -------------------------------------------------------------- 
  source('GPCore.R')
  source('Models.R')

## --- Generate data ----------------------------------------------------------- 
  X = maximinLHS(30,3)
  Y = matrix(Model4(X), ncol=1)


## --- Build the emulator ------------------------------------------------------
  E = GPCore()
  E$InputData(X)
  E$OutputData(Y)
  E$SetCorFun('Mat32')
  E$Obs = 2
  E$OE = 1e-4

## --- Optimise ----------------------------------------------------------------
  delta.init = runif(n=3, min=0, max=1);
  optim.result = E$Optimise(delta.init)


## --- Implausibility ----------------------------------------------------------
  Xp = matrix(runif(n=900000, min=0, max=1), ncol=3)
  I = E$Implausibility(Xp)


## --- Bin Data ----------------------------------------------------------------
  input1 = 1
  input2 = 2
  nb = 30
  BD = BinData(I,Xp,input1,input2,nb)

##
  xplot = (1:nb)/nb - 0.5/nb;
  
  filled.contour(xplot, xplot, BD$M, xlab="Input 1", 
                 ylab="Input 2", levels=seq(0, max(BD$M), len=30),
                 color.palette=rev.rain.colors)


## --- Clipped minimum implausibility plot -------------------------------------
  cutoff = 3
  Mtemp = BD$M
  Mtemp[Mtemp>cutoff] = cutoff
  filled.contour(xplot, xplot, Mtemp, xlab="Input 1", ylab="Input 2",
                 levels=seq(0, max(Mtemp), len=30),
		 color.palette=rev.rain.colors)

## --- Optical depth plot ------------------------------------------------------
  filled.contour(xplot, xplot, BD$D, xlab="Input 1",
                 ylab="Input 2", nlevels=25, 
                 color.palette=cold1)



## --- 3-d plot ----------------------------------------------------------------
  # if rgl is working on your machine you can set plot.using.rgl = 1, to 
  # see the 3d plot
  plot.using.rgl = 1
  
  if (plot.using.rgl){
    require('rgl')
    X.ni = Xp[I<3,]
    plot3d(X.ni[,1], X.ni[,2], X.ni[,3], col='green')
  }
    
print(c("Log Likelihood = ", E$L))
