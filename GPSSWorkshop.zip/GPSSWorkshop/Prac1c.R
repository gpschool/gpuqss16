## --- Sec 2.7 -----------------------------------------------------------------
  rm(list=ls())

## --- Load files -------------------------------------------------------------- 
  source('GPCore.R')
  source('Models.R')


## --- Generate data ----------------------------------------------------------- 
  X = matrix(c(0.0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.8, 0.9, 1),ncol=1)
  Y = Model3(X)

  xplot = matrix(seq(-0.2,1.2,length.out=100),ncol=1)
  yplot = Model3(xplot)

## --- Build the emulator ------------------------------------------------------ 
  E = GPCore()
  E$InputData(X)
  E$OutputData(Y)
  
  # Change here the mean function
  E$SetRegFun('RegFun0')

## --- Likelihood -------------------------------------------------------------- 
  N = 1000
  delta_max = 2
  delta = seq(from=0.0001, to=delta_max, length.out=N)
  LogLik = rep(0,N);
  
  for (k in 1:N) {
    LogLik[k] = E$LogLik(delta[k])$L
  }
  plot(delta,LogLik)
  deltahat = delta[which.max(LogLik)]
  deltahat

## --- Plot -------------------------------------------------------------------- 
  E$SetHyper(deltahat)
  E$Plot(xplot)
  lines(xplot,yplot)

