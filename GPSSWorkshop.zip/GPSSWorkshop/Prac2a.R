## ----------------------------------------------------------------------------- 
  rm(list=ls())

## --- Load files -------------------------------------------------------------- 
  source('GPCore.R')
  load('Model2.RData')
  
## --- Generate data ----------------------------------------------------------- 
  # First round
  ind = c(1, 40, 80, 120, 160, 200)
  # Second round
  #ind = c(1, 40, 50, 60, 70, 80, 120, 160, 200)
  X = matrix(x_M2[ind,1], ncol=1)
  Y = matrix(y_M2[ind,1], ncol=1)


## --- Build the emulator ------------------------------------------------------
  E = GPCore()
  E$InputData(X)
  E$OutputData(Y)
  
  E$SetCorFun('Mat32')

## --- Likelihood --------------------------------------------------------------
  N = 1000
  delta_max = 2
  delta = seq(from=0.0001, to=delta_max, length.out=N)
  LogLik = rep(0,N);
  
  for (k in 1:N) {
    LogLik[k] = E$LogLik(delta[k])$L
  }
  plot(delta,LogLik)
  deltahat = delta[which.max(LogLik)]
  deltahat

## --- Plot --------------------------------------------------------------------
  E$SetHyper(deltahat)
  E$Plot(x_M2)
  lines(x_M2,y_M2)

## --- Implausibility ----------------------------------------------------------
  E$Obs = -35;
  E$OE  = 0.025 
  I = E$Implausibility(x_M2)
  plot(x_M2, I, type='l')
  
  ni_ind = which(I<3)
##
  xlim = c(0,1)
  ylim = c(-55,10)
  E$Plot(x_M2, xlim=xlim, ylim=ylim)
  lines(x_M2, y_M2)
  points(x_M2[ni_ind,], y_M2[ni_ind], col='green')
  abline(h = c(E$Obs - 2*E$OE^0.5, E$Obs, E$Obs + 2*E$OE^0.5), 
         lty = c(1, 3, 1))
  points(x_M2, rep(ylim[1], length = dim(x_M2)[1]), col='red')
  points(x_M2[ni_ind,], rep(ylim[1], length = length(ni_ind)), col='green')



