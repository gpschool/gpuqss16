## --- Load the necessary packages -------------------------------------------- 
require('pdist')
require('lhs')

## --- Model 1 function ------------------------------------------------------- 
Model1 <- function(x){
# Model1 function for the tutorial
#
# Args:
#    x: input
#    
# Returns:
#   sin(2\pi x)

  return(sin(2*pi*x))
}

## --- Model 3 function ------------------------------------------------------- 
Model3 <- function(x){
# Model3 function for the tutorial
#
# Args:
#    x: input
#    
# Returns:
#  sin(10\pi x) + 0.1 exp(5x);

  sin(10*pi*x) + 0.1* exp(5*x);
}

## --- Model 4 function ------------------------------------------------------- 
Model4 <- function(X){
# Model4 function for the tutorial
#
# Args:
#    x: input (n x 3) matrix
#    
# Returns:
#  x1^2 + x2^2 + x3 (n x 1) matrix 

  X[,1]^2 + X[,2]^2 + X[,3];
}

## --- BinData function ------------------------------------------------------- 
BinData = function (Imp,X,input1,input2,n_bins){
# Function for binning implausibility data 
# 
# Args:
#    Imp   : Implausibility (n x 1) 
#    X     : Points where the implausibility was evaluated (n x p) 
#    input1: first input (column of the X matrix)
#    input2: second input (column of the X matrix)
#    n_bins: bins to be created
#    
# Returns:
#  A list with fields:
#    M: the minimum implausibility matrix    
#    D: the optical depth matrix    
#    
  thres = 3
  
  binind1 = ceiling(X[,input1] * n_bins)
  binind2 = ceiling(X[,input2] * n_bins)

  
  D = matrix(0, nrow=n_bins, ncol=n_bins) 
  M = matrix(0, nrow=n_bins, ncol=n_bins) 
  
  for (k in  1:n_bins){
      for (l in  1:n_bins){
          samples_in_bin = which(binind1==k & binind2 ==l) 
          if (length(samples_in_bin) > 0){
            D[k,l] = length(which(Imp[samples_in_bin]<thres)) / 
                     length(samples_in_bin)
            M[k,l] = min(Imp[samples_in_bin])        
          } else{
            D[k,l] = 0
            M[k,l] = thres
          } 
      }
  }

  return(list(M=M, D=D))
}

cold1 <- function(n,fra1=0.1,fra2=0.25,fra3=0.1){

  n4 <- round(n*fra3,0)
  n1 <- 1
  n2 <- round(n*fra2,0)
  n3 <- n-n1-n2-n4
  
  co1 <-  hsv(0.68,0.25,0.55)
  co2 <- rainbow(n2,st=3/6,en=3.001/6,alpha=seq(0,0.9,len=n2))
  co3 <- rainbow(n3,st=3/6,en=5.05/6)
  co4 <- rainbow(n4,st=5.1/6,en=5.3/6)
  co <- c(co1,co2,co3,co4)
  co
}

rev.rain.colors <- colorRampPalette(rev(c("red","yellow","green")))






