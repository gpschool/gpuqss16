##
  rm(list=ls())
  
## --- 2.1 Preparation ------------------------------------------------------------
  source('GPCore.R')
  source('Models.R')


## --- Generate data ---
  X = matrix(c(0,0.25,0.5,0.9,1), ncol = 1)
  Y = Model1(X)
  xplot = matrix(seq(-0.2, 1.2, length=100), ncol=1)
  yplot = Model1(xplot)



## --- 2.2 Building the emulator --------------------------------------------------
  E = GPCore()    # define the emulator
  E$InputData(X)  # load the input data
  E$OutputData(Y) # load the output data



## --- 2.3 Varying the correlation lengths ----------------------------------------
  E$SetHyper(1)  # Set the correlation length to 1 
  E$Plot(xplot)  # Plot the emulator's posterior 
  lines(xplot,yplot) # Plot the simulator



## --- 2.4 Maximum likelihood -----------------------------------------------------
  N = 1000
  # preallocate the values of delta
  delta = seq(from=0.0001, to=1.3, length.out=1000)
  # preallocate storage for the log likelihood
  LogLik = rep(0, N)
  for (k in 1:N) {
    # calculate the likelihood for delta[k]
    LogLik[k] = E$LogLik(delta[k])$L
  }

  plot(delta, LogLik)   # plot
  deltahat =   delta[which.max(LogLik)]   # find the maximum

## --- 2.5 The nugget -------------------------------------------------------------

  E$SetHyper(1.5,1e-9)
  r = E$Predict(xplot)
  plot(diag(r$V))
  min(diag(r$V))
  
  E$SetHyper(1.5,1e-8)
  r1 = E$Predict(xplot)
  plot(diag(r1$V),type='l')
  min(diag(r1$V))
  
  plot(diag(r$V),type='l')
  lines(diag(r1$V),col='green')


## --- Increase the nugget ---
  E$SetHyper(0.7,1e-14)
  E$Plot(xplot)
  lines(xplot,yplot)

