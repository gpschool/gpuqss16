require(pdist)

RegFun0 = function(X){
# Zero-th order regression function
# 
# Args:
#    X: Input points (n x p) 
#    
# Returns:
#  An (n x 1) matrix of ones
#    
    n = dim(X)[1]
    return(matrix(1,n,1))
}

RegFun1 = function(X){
# First order regression function
# 
# Args:
#    X: Input points (n x p) 
#    
# Returns:
#  The (n x (p + 1)) matix [1, X]
#    
    n = dim(X)[1];
    ones = matrix(1,n,1);
    return(cbind(ones,X));
}

RegFun3 = function(X){
# Third order regression function
# 
# Args:
#    X: Input points (n x p) 
#    
# Returns:
#  The (n x (3p + 1)) matix [1, X, X^2, X^3]
#    
    n = dim(X)[1];
    ones = matrix(1,n,1);
    return(cbind(ones,X,X^2,X^3));
}

WDist = function(delta,X,Y){
# Weighted distance function
# 
# Args:
#    delta: (p x 1) vector of correlation lengths
#    X: Input points (n1 x p) 
#    Y: Input points (n2 x p) 
#    
# Returns:
#  WDist(delta, X) returns the (n1 x n1) matrix of weighted distances 
#                  between the rows of X
#  WDist(delta, X, Y) returns the (n1 x n2) matrix of weighted distances 
#                  between the rows of X and Y
#    
    n = dim(X)[1];
    p = dim(X)[2];

    if (length(delta)!=p) stop('WDist:delta does not have p elements')

    Xw = t(t(X)/delta); # divide X row-wise by delta

    if (missing(Y)){ # auto distance requested
        return(as.matrix(dist(Xw)));
    } else {         # cross distance requested
        Yw = t(t(Y)/delta);
        return(as.matrix(pdist(Xw,Yw)));
    }

}

GausCor = function(delta,X,Xp){
# Weighted distance function
# 
# Args:
#    delta: (p x 1) vector of correlation lengths
#    X : Input points (n1 x p) 
#    Xp: Input points (n2 x p) 
#    
# Returns:
#  WDist(delta, X) returns the (n1 x n1) Gaussian correlation matrix 
#                  between the rows of X
#  WDist(delta, X, Xp) returns the (n1 x n2) Gaussian correlation matrix 
#                  between the rows of X and Xp
#    
    D = WDist(delta,X,Xp);
    return( exp(-D^2) )

}

Mat32 = function(delta,X,Xp){
# Weighted distance function
# 
# Args:
#    delta: (p x 1) vector of correlation lengths
#    X : Input points (n1 x p) 
#    Xp: Input points (n2 x p) 
#    
# Returns:
#  WDist(delta, X) returns the (n1 x n1) Matern 3/2 correlation matrix 
#                  between the rows of X
#  WDist(delta, X, Xp) returns the (n1 x n2) Matern 3/2 correlation matrix 
#                  between the rows of X and Xp
#    
    D = WDist(delta,X,Xp);
    return( (1 + sqrt(3) * D) * exp(-sqrt(3)*D) )

}

Mat52 = function(delta,X,Xp){
# Weighted distance function
# 
# Args:
#    delta: (p x 1) vector of correlation lengths
#    X : Input points (n1 x p) 
#    Xp: Input points (n2 x p) 
#    
# Returns:
#  WDist(delta, X) returns the (n1 x n1) Matern 5/2 correlation matrix 
#                  between the rows of X
#  WDist(delta, X, Xp) returns the (n1 x n2) Matern 5/2 correlation matrix 
#                  between the rows of X and Xp
#    
    D = WDist(delta,X,Xp);
    return( (1 + sqrt(5) * D + 5/3 * D^2 ) * exp(-sqrt(5) * D) )

}

GPCore <- setRefClass("GPCore",
    fields = list(
        X = "matrix",   # Input training data (n x p)
        Y = "matrix",   # Output training data (n x 1)
        H = "matrix",   # Regression Matrix
        n = "numeric",  # Number of training points 
        p = "numeric",  # Number of input dimensions
        q = "numeric",  # Number of regression functions
        RegFun = "function", # Regression function
        CorFun = "function", # Correlation function
        RegFunName = "character", # Regression function name
        CorFunName = "character", # Correlation function name
        delta  = "vector",   # Correlation lengths
        sigma  = "numeric",  # Estimate of sigma^2 given delta
        beta   = "matrix",   # Estimate of beta given delta
        nu     = "numeric",  # Nugget
        # !! C_A and C_HAH are upper diagonal !! 
        C_A    = "matrix",   # Cholesky decomp. of A given delta
        C_HAH  = "matrix",   # Cholesky decomp. of HA^{-1}H given delta
        L      = "numeric",  # Likelihood given delta
        EmulatorSetup = "numeric",  # Estimate of beta given delta
        EmulatorReady = "numeric",  # Estimate of beta given delta
        FixedNugget = "logical",
        Obs = "numeric",
        OE  = "numeric",
        MD  = "numeric",
        OV  = "numeric"
    ),

    methods = list(

        initialize = function(){
        # Initialisation function 
            .self$SetRegFun('RegFun1')
            .self$SetCorFun('GausCor')
            .self$EmulatorSetup = 0
            .self$EmulatorReady = 0
            .self$nu = 1e-12
            .self$FixedNugget = T
            .self$Obs = 0
            .self$OE  = 0
            .self$MD  = 0
            .self$OV  = 0
        },

        show = function(){
        # Show function
            cat("Input data \"X\" : ")
            cat("<",dim(X)[1], " x ", dim(X)[2],"> matrix. \n",sep = "")

            cat("Output data \"Y\": ")
            cat("<",dim(Y)[1], " x ", dim(Y)[2],"> matrix. \n",sep = "")
            cat("\n")

            cat("no. of training data \"n\"       : ", n, "\n", sep = "")
            cat("no. of input dimensions \"p\"    : ", p, "\n", sep = "")
            cat("no. of regression functions \"q\": ", q, "\n", sep = "")
            cat("\n")

            cat("Regression function : ", .self$RegFunName, "\n", sep = "")
            cat("Correlation function: ", .self$CorFunName, "\n", sep = "")
            cat("\n")

            cat("Regression matrix  \"H\": ")
            cat("<",dim(H)[1], " x ", dim(H)[2],"> matrix. \n",sep = "")
            cat("\n")

            cat("Correlation lengths \"delta\": \n")
            print(.self$delta)
            cat("\n")

            cat("\"sigma\":",.self$sigma,"\n")
            cat("\n")

            cat("\"beta\": ")
            cat("<",dim(.self$beta)[1], " x ", dim(.self$beta)[2],"> matrix. \n",sep = "")
            cat("\n")

            cat("\"nu\":",.self$nu,"\n")

            cat("Fixed nu:",.self$FixedNugget,"\n")
            cat("\n")

            cat("Likelihood \"L\":",.self$L,"\n")


        },

        Plot = function(X,xlim,ylim){
        # Plot function (works only for 1-dimensional emulators)
        # 
        # Args:
        #    X : (n x p) matrix of points where to plot the emulator.
        #    xlim: (2 x 1) vector x axis limits for the plot
        #    ylim: (2 x 1) vector y axis limits for the plot
        #    
          if (!is.matrix(X)) { 
            stop('X must be a matrix')
          }

          if (dim(X)[2] != 1) {
            stop('X must be a 1 column matrix')
          }

          if (.self$p>1) {
            stop('Plot function works only for one dimensional emulators')
          }

          P = .self$Predict(X)

          upper.ci = P$m + 2*(diag(P$V)^0.5)
          lower.ci = P$m - 2*(diag(P$V)^0.5)

          xpoly = c(X,X[dim(X)[1]:1,1])
          ypoly = c(upper.ci,lower.ci[length(lower.ci):1])

          if (missing(xlim) & missing(ylim)) {
            xlim = c(min(X),max(X))
            ylim = c(min(lower.ci),max(upper.ci))
          }

          plot(x=xlim[2] + 1, y=ylim[2] + 1, xlim=xlim, ylim=ylim, 
               xlab="x", ylab="y")

          polygon(x=xpoly, y=ypoly ,col='#6599FF', border=NA)

          lines(x=X, y=P$m, col='#FFDE00')
          
          points(x=.self$X, y=.self$Y, pch=4, col='#FF9900')


        },

        InputData = function(X){
        # Load input training data to the emulator
        # 
        # Args:
        #    X: Input points (n x p). Must be a matrix.
        #    
            if (!is.matrix(X)) {
              stop('X must be a matrix')
            }
            .self$X <- X;
            .self$n <- dim(X)[1];
            .self$p <- dim(X)[2];
            .self$EmulatorSetup <- 0;
            .self$EmulatorReady <- 0;
        },

        OutputData = function(Y){
        # Load output training data to the emulator
        # 
        # Args:
        #    Y: Output points (n x 1). Must be a matrix.
        #    
            if (!is.matrix(Y)) stop('Y must be a matrix')
            .self$Y <- Y;
            .self$EmulatorSetup <- 0;
            .self$EmulatorReady <- 0;
        },

        SetRegFun = function(funname = stop('SetRegFun argument missing')){
        # Set the regression function
        # 
        # Args:
        #    funname: can either be 'RegFun0', 'RegFun1', or 'RegFun3'
        #             for the 0th 1st and 3rd order regression functions 
        #    

            if (funname == 'RegFun0'){
                .self$RegFun     <- RegFun0;
                .self$RegFunName <- 'RegFun0'

            } else if (funname == 'RegFun1'){
                .self$RegFun     <- RegFun1;
                .self$RegFunName <- 'RegFun1'

            } else if (funname == 'RegFun3'){
                .self$RegFun     <- RegFun3;
                .self$RegFunName <- 'RegFun3'

            } else {
                warning('SetRegFun only accepts RegFun1 or RegFun3 as arguments')

            }

            .self$EmulatorSetup <- 0;
            .self$EmulatorReady <- 0;
        },

        SetCorFun = function(funname = stop('SetCorFun argument missing')){
        # Set the correlation function
        # 
        # Args:
        #    funname: can either be 'GausCor', 'Mat32', or 'Mat52'
        #             for the Gaussian, Matern 3/2 and Matern 5/2
        #             functions respectively
        #    

            if (funname == 'GausCor'){
                .self$CorFun     <- GausCor;
                .self$CorFunName <- 'GausCor'

            } else if (funname == 'Mat32'){
                .self$CorFun    <- Mat32;
                .self$CorFunName <- 'Mat32'

            } else if (funname == 'Mat52'){
                .self$CorFun    <- Mat52;
                .self$CorFunName <- 'Mat52'

            } else {
                warning('SetCorFun only accepts GausCor, Mat32, Mat52 as arguments')

            }

            .self$EmulatorSetup <- 0;
            .self$EmulatorReady <- 0;
        },

        CheckEmulatorSetup = function(){
        # Internal function checking if the emulator is setup
        # i.e. whether the input and output data are loaded
        # if their dimensions agree and if the regression matrix
        # has the correct form. 
        #    
            .self$EmulatorSetup = 0;

            if (prod(dim(.self$X)) == 0 ){ stop('Input data are not set.') }

            if (prod(dim(.self$Y)) == 0 ){ stop('Output data are not set.') }

            if (dim(.self$Y)[2] != 1){ stop('Output data must be in column vector format') }

            if (dim(.self$Y)[1] != .self$n){ stop('The number of input and output data are not equal') }

            # Check Regression function
            Htemp = .self$RegFun(.self$X);
            if (dim(Htemp)[1] != .self$n){ stop('The regression function should return a matrix n rows') }

            .self$H = Htemp
            .self$q = dim(.self$H)[2]

            .self$EmulatorSetup = 1;


        },

        LogLik = function(delta,nu.l){
        # Log likelihood function
        # 
        # Args:
        #    delta: (p x 1) vector of correlation lengths
        #    nu.l : nugget (scalar)
        #    
        # Returns:
        #  A list with fields:
        #         L    : the log likelihood
        #         beta : the estimate beta hat
        #         sigma: the estimate sigma hat
        #         C_A  : the cholesky decomposition of matrix A
        #         C_HAH: the cholesky decomposition of matrix H'A^{-1}H
        #    
            if (missing(nu.l)) {
              nu.l = .self$nu
            }
        
            R = list()

            if (.self$EmulatorSetup == 0){ .self$CheckEmulatorSetup() }

            A = .self$CorFun(delta,.self$X)
            A = A + diag(.self$n) * nu.l

            # *Upper cholesky decomposition*
            R$C_A = try(chol(A),silent = T)

            if (class(R$C_A) == "try-error") { R$L = -Inf; return(R) }
            lndetA = 2*sum(log(diag(R$C_A)))

            if (lndetA == -Inf){ R$L = -Inf; return(R) }

            HAH = solve(t(R$C_A), .self$H);
            HAH = t(HAH) %*% HAH

            R$C_HAH = try(chol(HAH), silent=T)
            if (class(R$C_HAH) == "try-error") { R$L = -Inf; return(R) }


            temp = solve(R$C_A,solve(t(R$C_A),.self$Y))
            temp = t(.self$H) %*% temp
            R$beta = solve(R$C_HAH,solve(t(R$C_HAH),temp))

            R$sigma = solve(t(R$C_A), .self$Y - .self$H %*% R$beta)
            R$sigma = t(R$sigma) %*% R$sigma /(.self$n  - .self$q - 2)
            R$sigma = as.numeric(R$sigma)

            R$L = ( -0.5 *lndetA - sum(log(diag(R$C_HAH))) 
                    - (.self$n - .self$q)/2 * log(R$sigma) )


            return(R)
            

        },

        SetHyper = function(delta, nu.l){
        # Set hyperparameters to the emulator
        # 
        # Args:
        #    delta: (p x 1) vector of correlation lengths
        #    nu.l : nugget (scalar)
        #    
        # Omitting nu.l uses the default or last used value of the nugget
        #    
            if (missing(nu.l)) {
              nu.l = .self$nu
            }
 
            R = .self$LogLik(delta,nu.l)

            if (R$L == -Inf) {
              stop('Could not calculate the likelihood for 
                    these parameter values') 
            }
            
            .self$delta         = delta;
            .self$sigma         = R$sigma;
            .self$beta          = R$beta;
            .self$nu            = nu.l;
            .self$L             = R$L;
            .self$C_A           = R$C_A;
            .self$C_HAH         = R$C_HAH;
            .self$EmulatorReady = 1;

        },

        Optim_aux = function(tau){
        # Internal auxiliary optimisation function
        # 
        # Args:
        #    *transformed* correlation lengths and nugget
        #    
        # Returns:
        #  Negative log likelihood
        #    

          if (.self$FixedNugget) {

            delta.l = exp(tau/2)

            R = .self$LogLik(delta.l)

          } else {

            delta.l = exp(tau[1:length(tau)-1]/2)
            nu.l    = exp(tau[length(tau)])

            R = .self$LogLik(delta.l,nu.l)

          }

            return(-R$L)

        },

        Optimise = function(delta, nu){
        # Optimisation function 
        # 
        # Args:
        #    delta: (p x 1) vector of correlation lengths (initial guess)
        #    nu   : nugget (scalar) (initial guess)
        #    
        # Usage:
        #  Let E be a member of the GPCore class 
        #  If E$FixedNugget = T
        #     E$Optimise(delta) will optimise delta keeping the nugget fixed.
        #  If E$FixedNugget = F
        #     E$Optimise(delta, nu) will jointly optimise delta and nu 
        #    
          if (.self$FixedNugget) {

            initial_value = c(2*log(delta))
  
            opt.result <- optim(par = initial_value, 
                               fn = .self$Optim_aux, 
                               method = "BFGS",
                               control = list(maxit = 10000))
            

            delta.l = exp(opt.result$par/2)

            opt.result$delta = delta.l

            .self$SetHyper(delta.l);

          } else {
            if (missing(nu)){
              stop('Optimise: please provide an initial guess for the nugget')
            }

            initial_value = c(2*log(delta),log(nu))
  
            opt.result <- optim(par = initial_value, 
                               fn = .self$Optim_aux, 
                               method = "BFGS",
                               control = list(maxit = 10000))
            

            delta.l = exp(opt.result$par[1:length(opt.result$par)-1]/2)
            nu.l    = exp(opt.result$par[length(opt.result$par)])

            opt.result$delta = delta.l
            opt.result$nu    = nu.l

            .self$SetHyper(delta.l,nu.l);

          }

          return(opt.result)

        },

        Predict = function(Xp){
        # Posterior calculation function 
        # 
        # Args:
        #    Xp: Points for evaluating the posterior (n x p) (matrix)
        #    
        # Returns:
        #  A list with fields: 
        #    m: the posterior mean (n x 1) (matrix)
        #    V: the posterior covariance (n x n) (matrix)
        #    
            if (!.self$EmulatorReady){ stop('Emulator not ready, please set the hyperparameters') }

            Hp = .self$RegFun(Xp)
            Ap = .self$CorFun(.self$delta,Xp)
            Ac = .self$CorFun(.self$delta,.self$X,Xp)

            # Posterior mean calculation
            # Y - H*beta
            temp = .self$Y - .self$H %*% .self$beta;

            # A^{-1} * (Y - H*beta)
            temp = solve(.self$C_A,solve(t(.self$C_A),temp))

            # m = Hp * beta + Ac' * temp
            m = Hp %*% .self$beta + t(Ac) %*% temp


            # Posterior variance calculation

            # Calculate the term U2 defined as
            # U2 = Ac' * A^{-1} * Ac
            U2 = solve(t(.self$C_A),Ac);
            U2 = t(U2) %*% U2


            # Calculate the term U3 defined as
            # U3 = (Hp - Ac'*A^{-1}*H) * (H'*A^{-1}*H)^{-1} * (Hp - Ac'*A^{-1}*H)' 

            # temp = A^{-1} * H 
            temp = solve(.self$C_A,solve(t(.self$C_A),.self$H))

            # temp = (Hp - Ac' * temp)'
            temp = t(Hp - t(Ac) %*% temp)
            
            # U3 = ...
            U3 = solve(t(.self$C_HAH),temp)
            U3 = t(U3) %*% U3

            V = .self$sigma*(Ap - U2 + U3)

            if (any(diag(V)<0)){
              warning('GPCore$Predict: Some posterior variances are negative; possible numerical error.')
            }

            return(list(m=m,V=V))

        },

        PredictDiag = function(Xp){
        # Posterior calculation function with diagonal covariance matrix
        # 
        # Args:
        #    Xp: Points for evaluating the posterior (n x p) (matrix)
        #    
        # Returns:
        #  A list with fields: 
        #    m: the posterior mean (n x 1) (matrix)
        #    V: the posterior variance  (n x 1) (matrix)
        #    
            if (!.self$EmulatorReady){ stop('Emulator not ready, please set the hyperparameters') }

            np = dim(Xp)[1]

            Hp = .self$RegFun(Xp)
            Ap = matrix(1, nrow = np, ncol=1)
            Ac = .self$CorFun(.self$delta,.self$X,Xp)

            # Posterior mean calculation
            # Y - H*beta
            temp = .self$Y - .self$H %*% .self$beta;

            # A^{-1} * (Y - H*beta)
            temp = solve(.self$C_A,solve(t(.self$C_A),temp))

            # m = Hp * beta + Ac' * temp
            m = Hp %*% .self$beta + t(Ac) %*% temp


            # Posterior variance calculation

            # Calculate the term U2 defined as
            # U2 = Ac' * A^{-1} * Ac
            U2 = solve(t(.self$C_A),Ac);
            U2 = matrix(colSums(U2^2), ncol = 1)


            # Calculate the term U3 defined as
            # U3 = (Hp - Ac'*A^{-1}*H) * (H'*A^{-1}*H)^{-1} * (Hp - Ac'*A^{-1}*H)' 

            # temp = A^{-1} * H 
            temp = solve(.self$C_A,solve(t(.self$C_A),.self$H))

            # temp = (Hp - Ac' * temp)'
            temp = t(Hp - t(Ac) %*% temp)
            
            # U3 = ...
            U3 = solve(t(.self$C_HAH),temp)
            U3 = matrix(colSums(U3^2), ncol = 1)

            V = .self$sigma*(Ap - U2 + U3)

            if (any(diag(V)<0)){
              warning('GPCore$Predict: Some posterior variances are negative; possible numerical error.')
            }

            return(list(m=m,V=V))

        },

        Validate = function(Xv, Yv) {
        # Validation function
        # 
        # Args:
        #    Xv: the input validation points (n x p) (matrix)
        #    Yv: the output validation points (n x 1) (matrix)
        #    
        # Returns:
        #  A list with fields:
        #    spe: individual prediction errors
        #    Ms : scaled Mahalanobis distance
        #    
        	Pred = .self$Predict(Xv)
        	
        	nv <- dim(Xv)[1]
        
        	par(mfrow = c(2, 1))
        	
                errors = Yv - Pred$m;
                stderrors = errors / sqrt(diag(Pred$V))
                
                plot(stderrors, ylim = c(-1.1,1.1)*max(abs(stderrors),2.5),
                     xlab = 'Index', ylab = 'Standardised residual',
                     main = 'Standardised prediction errors')

        	abline(h = c(-1, 0, 1) * qnorm(0.975), lty = c(3, 1, 3))
        
        	# Mahalanobis distance
        	MahD <- t(errors) %*% solve(Pred$V, errors) * (.self$n - .self$q) / nv / (.self$n - .self$q - 2)
        	x_end <- max(MahD, qf(0.999, nv, .self$n - .self$q)) * 1.1
        	x_plot <- seq(0, x_end, length = 200)
        	plot(x_plot , df(x_plot, nv, .self$n - .self$q), type = "l", xlab = "x", ylab = "Density", main="Mahalanobis test")
        	x_low <- seq(0, qf(0.025, nv, .self$n - .self$q), length = 100)
        	x_upp <- seq(qf(0.975, nv, .self$n - .self$q), x_end, length = 100)
        	polygon(c(x_low, rev(x_low)), c(df(x_low, nv, .self$n - .self$q ), rep(0, 100)), col = "black")	
        	polygon(c(x_upp, rev(x_upp)), c(df(x_upp, nv, .self$n - .self$q), rep(0, 100)), col = "black")	
        	abline(v = MahD, col = "red")

                par(mfrow = c(1,1))

                return(list(spe=stderrors, Ms=MahD))
        	
        },

        Implausibility = function(Xv){
        # The implausibility function 
        # 
        # Args:
        #    Xv : Points to evaluate the implausibility at (n x p) (matrix) 
        #    
        # Returns:
        #  I: the implausibility of points Xv
        #  
        #  Also requires setting the fields:
        #    Obs: the observation    
        #    OE:  the observation error
        #    MD: the model discrepancy  (optional)
        #    OV: the ensemble uncertainty (optional)
        #    
          R = .self$PredictDiag(Xv)
          I = abs(.self$Obs - R$m) / 
             ( R$V + .self$OV + .self$MD + .self$OE)^0.5
          return(I)
        }


    )
)


