## --- Sec 2.8 ----------------------------------------------------------------- 
  rm(list=ls())

## --- Load files -------------------------------------------------------------- 
  source('GPCore.R')
  source('Models.R')


## --- Generate data ----------------------------------------------------------- 
  #For the first round
  X = matrix(c(0, 0.18, 0.39, 0.63, 0.8, 1),ncol=1)
  #For the second round
  #X = matrix(c(0, 0.05, 0.18, 0.25, 0.39, 0.42, 0.63, 0.7, 0.8,  1),ncol=1)
  
  Y = Model3(X)
  
  xplot = matrix(seq(-0.2,1.2,length.out=100),ncol=1)
  yplot = Model3(xplot)


## --- Build the emulator ------------------------------------------------------
  E = GPCore()
  E$InputData(X)
  E$OutputData(Y)
  E$SetHyper(1,1e-10)

## --- Likelihood --------------------------------------------------------------
  N = 1000
  delta_max = 2
  delta = seq(from=0.0001, to=delta_max, length.out=N)
  LogLik = rep(0,N);
  
  for (k in 1:N) {
    LogLik[k] = E$LogLik(delta[k])$L
  }
  plot(delta,LogLik)
  deltahat = delta[which.max(LogLik)]
  deltahat

## --- Plot --------------------------------------------------------------------
  E$SetHyper(deltahat)
  E$Plot(xplot)
  lines(xplot,yplot)

## --- Get validation data -----------------------------------------------------
  #For the first round
  Xv = matrix(c(0.05, 0.25, 0.42, 0.7),ncol=1)
  #For the second round
  #Xv = matrix(c(0.1, 0.33, 0.55, 0.90),ncol=1)
  
  Yv = Model3(Xv)
  points(Xv,Yv)

## --- Calculate the diagnostics -----------------------------------------------
  R = E$Predict(Xv)
  spe = (Yv - R$m) / diag(R$V)^0.5
  M = t(Yv - R$m) %*% solve(R$V, Yv - R$m)
  Ms = (E$n - E$q) / (dim(Yv)[1]*(E$n - E$q - 2))*M

## --- Do it with the Validate function ----------------------------------------
  dev.new()
  E$Validate(Xv,Yv)
